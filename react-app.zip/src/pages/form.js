import React, {Component} from'react'
import { Button } from 'react-bootstrap';

class Form extends Component{
constructor(props){
    super(props);
    this.state={
        fname:'',
        lname:''
    }
    //this.handleChange=this.handleChange.bind(this);
}
handleChange = (e) => {
    const{name, value} = e.target
    this.setState({[name]:value})
}

render(){
    return(
        <React.Fragment>
            <h1>Form</h1>
            <form>
                <input type="text" name="firstName" value={this.state.fname} onChange={this.handleChange} placeholder="Enter First Name"/><br/>
                <input type="text" name="lastName" value={this.state.lname} onChange={this.handleChange} placeholder="Enter Last Name"/><br/>
                <Button className="btn btn-primary">Submit</Button>
            </form>
        </React.Fragment>
    )
}
}
export default Form;