import React from 'react';
import 'bootstrap/scss/bootstrap.scss';
import './App.css';
//import { Header, Button, Container, Row, Col } from 'react-bootstrap';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import Shop from './pages/shop.js';
import About from './pages/about.js';
import Contact from './pages/contact.js';
import Example from './pages/hook.js';
import ToDoDragDropDemo from './pages/Dnd.js';
import Mycart from './pages/Mycart.js';
import Form from './pages/form.js';


export default class App extends React.Component {
	render(){
		return (
     
		<Router>
  
<div className="container-fluid">
          <header className="nav-down">
            <nav className="navbar navbar-expand-lg navbar-dark bg-dark text-right">
              <ul className="navbar-nav mr-auto">
                <li><Link to={'/pages/shop'} className="nav-link"> Shop </Link></li>
                <li><Link to={'/pages/contact'} className="nav-link">Contact</Link></li>
                <li><Link to={'/pages/about'} className="nav-link">About</Link></li>
                <li><Link to={'/pages/hook'} className="nav-link">Hook</Link></li>
                <li><Link to={'/pages/DnD'} className="nav-link">DnD</Link></li>
                <li><Link to={'/pages/form'} className="nav-link">Form</Link></li>
              </ul>
              <span style={{'display':'inline-block'}}>
                <ul className="navbar-nav mr-auto"><li><Link to={'/pages/cart'} className="nav-link"> My cart </Link></li></ul>
              </span>
            </nav>
          </header>
          <hr />
          <Switch>
              <Route exact path='/pages/shop' component={Shop} />
              <Route path='/pages/cart' component={Mycart} />
              <Route path='/pages/contact' component={Contact} />
              <Route path='/pages/about' component={About} />
              <Route path='/pages/hook' component={Example} />
              <Route path='/pages/DnD' component={ToDoDragDropDemo} />
              <Route path='/pages/form' component={Form} /> 
          </Switch>
        </div>
        
</Router>

  );
	}
  
}


