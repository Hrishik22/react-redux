import React, { useState } from 'react';
import { Button, Container, Row, Col } from 'react-bootstrap';
import svgmap from '../india.svg';

export default function Example() {
  // Declare a new state variable, which we'll call "count"
  const [count, setCount] = useState(0);

  return (
    <Container fluid="true">
      <p>You clicked {count} times</p>
      <Button onClick={() => setCount(count + 1)}>
        Click me
      </Button>
      <Row>
          <Col>
                <p>Click on the state</p>
                <img src={svgmap} alt="map"></img>
          </Col>
          <Col>
                <p>You have selected {}</p>
          </Col>
      </Row>
    </Container>
  );
}