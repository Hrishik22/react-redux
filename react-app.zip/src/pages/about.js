import React, { Component } from 'react';
import logo from '../loader1.svg';
import { Container } from 'react-bootstrap';

class About extends Component {
	constructor(props) {
    super(props);
    this.state = {
      error: null,
      isLoaded: false,
      photos: []
    };
  }
	async componentDidMount() {
    await fetch("https://jsonplaceholder.typicode.com/photos")
      .then(res => res.json())
      .then(
        (photos) => {
          this.setState({
            isLoaded: true,
            photos: photos
          });
        },
        
        (error) => {
          this.setState({
            isLoaded: true,
            error
          });
        }
      )
  }
  render() {
    const { error, isLoaded, photos } = this.state;
    if (error) {
      return <div>Error: {error.message}</div>;
    } else if (!isLoaded) {
      return <Container className="text-center"><img src={ logo } alt="loader"/></Container>;
    } else {
      return (
        <div className="row">
          {photos.map(photos => (
            <div className="col-lg-3 text-center" key={photos.albumid}>
				<img src={photos.thumbnailUrl} alt={photos.title}/>
				<h3>{photos.id}</h3>
              <p>{photos.title}</p>
            </div>
          ))}
        </div>
      );
    }
  }
}

export default About;