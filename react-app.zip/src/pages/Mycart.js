import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
import {removeItem, addQuantity, subtractQuantity} from './actions/cartAction'

class Mycart extends Component {

     //to remove the item completely
     handleRemove = (id)=>{
        this.props.removeItem(id);
    }
    //to add the quantity
    handleAddQuantity = (id)=>{
        this.props.addQuantity(id);
    }
    //to substruct from the quantity
    handleSubtractQuantity = (id)=>{
        this.props.subtractQuantity(id);
    }

  render() {
      let addedItems = this.props.items.length ?
      (
          this.props.items.map(item=>{
              return(
                  <li className="row" key={item.id}>
                      
                        <div className="col-md-4">
                            <img style={{width:'100%'}} src={item.img} alt={item.title} />
                        </div>
                        <div className="col-md-8"> 
                            <h5>{item.title}</h5>
                            <p>{item.desc}</p>
                            <p><strong>Price: {item.price}$</strong></p>
                            <p><strong>Quantity: {item.quantity}</strong>
                            <div className="add-remove">
                            <Link to="./cart"><span className="glyphicon glyphicon-chevron-up" onClick={()=>{this.handleAddQuantity(item.id)}}>Up</span></Link>
                            <Link to="./cart"><span className="glyphicon glyphicon-chevron-down" onClick={()=>{this.handleSubtractQuantity(item.id)}}>Down</span></Link>
                            </div>
                            </p>
                            <button className="btn btn-danger" onClick={()=>{this.handleRemove(item.id)}}>Remove</button>
                        </div>
                     
                          
                  </li>
              )
          })
      ):
      (
          <p>Nothing</p>
      )
    return (
        <div className="container">
			<h3>You have ordered:</h3>
            <ul className="list">
                {addedItems}
            </ul>
		</div>
    );
  }
}

const mapStateToProps = (state) =>{
    return{
        items: state.addedItems
    }
}
const mapDispatchToProps = (dispatch)=>{
    return{
        removeItem: (id)=>{dispatch(removeItem(id))},
        addQuantity: (id)=>{dispatch(addQuantity(id))},
        subtractQuantity: (id)=>{dispatch(subtractQuantity(id))}
    }
}


export default connect(mapStateToProps, mapDispatchToProps) (Mycart);