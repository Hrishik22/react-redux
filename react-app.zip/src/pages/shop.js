import React, { Component } from 'react';
import { connect } from 'react-redux';
import { addToCart } from './actions/cartAction'

class Shop extends Component {
  constructor(props){
    super(props);
    this.state={
      search:""
    }
  }

  handleClick = (id) =>{
    this.props.addToCart(id);
  }
  onchange = (e) =>{
    this.setState({search: e.target.value});
  }
  render() {
    const {search} = this.state;
   
    let itemList = this.props.items.map(item=>{
      if (search !== "" && item.title.toLowerCase().indexOf(search.toLowerCase()) === -1){
        return null;
      }
      return (
        <div className="col-md-4" key={item.id}>
            <div className="card">
            <img style={{width:'100%'}} src={item.img} alt={item.title}/>
              <div className="card-body">
                <h5 className="card-title">{item.title}</h5>
                <p className="card-text">{item.desc}</p>
                <p className="card-text"><strong>price: {item.price}$</strong></p>
                <button onClick={()=>{this.handleClick(item.id)}} className="btn btn-primary">Add</button>
              </div>
             
            </div>
		    </div>
    );
    })
    
    return(
    <div className="container">
      <input className="form-control" type ="text" name="search" placeholder="Type to Search" onChange={this.onchange}/>
       <h3 className="text-center">Our items</h3>
      <div className="row">
         {itemList}
      </div>
    </div>
    )
  }
}
const mapStateToProps = (state) => {
  return {
    items: state.items
  }
}

const mapDispatchToProps = (dispatch) =>{
  return{
    addToCart:(id)=>{dispatch(addToCart(id))}
  }
}

export default connect(mapStateToProps, mapDispatchToProps) (Shop);