import React, { Component } from 'react';
import { Container, Row, Col, Card } from 'react-bootstrap';

class Contact extends Component {
  constructor(props) {
    super(props);
    this.state = {
      error: null,
      isLoaded: false,
      photos: []
    };
  }
  async componentDidMount() {
    await fetch("https://jsonplaceholder.typicode.com/photos")
      .then( res => res.json())
      .then(
        (photos) => {
          this.setState({
            isLoaded: true,
            photos: photos

          });
        },
        // Note: it's important to handle errors here
        // instead of a catch() block so that we don't swallow
        // exceptions from actual bugs in components.
        (error) => {
          this.setState({
            isLoaded: true,
            error
          });
        }
      )
  }

  /*handleClick(album){
    console.log(album.album[0].title)
  }*/

  render() {
    const { error, isLoaded, photos } = this.state;
    // const albums = [...new Set(photos.albumId)];

    let res = photos.reduce((r, a) => {
      r[a.albumId] = r[a.albumId] || [];
      r[a.albumId].push(a);
      return r;
    }, Object.create(null));

    const albums = [];
    Object.keys(res).forEach((v, i) => {
      albums.push({
        "albumId": v,
        "album": res[v]
      });
    })
    // console.dir(albums);
    if (error) {
      return <div>Error: {error.message}</div>;
    } else if (!isLoaded) {
      return <div>Loading...</div>;
    } else {
      return (
        <Container>
          <Row>
            {albums.map(album => (


              <Col className="col-md-3 text-center" key={album.albumId}>

                <Card>
                  <div className="card-body">
                    {album.album[0].albumId}
                  </div>
                </Card>

              </Col>


            ))}
          </Row>
        </Container>

      );
    }
  }
}

export default Contact;